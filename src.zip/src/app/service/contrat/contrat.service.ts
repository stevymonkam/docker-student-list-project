import { tokenize } from '@angular/compiler/src/ml_parser/lexer';
import { Injectable } from '@angular/core';
import { AuthService } from 'src/app/service/auth/auth.service';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { ConfigService } from '../config/config.service';


@Injectable({
  providedIn: 'root'
})
export class ContratService {
 host: string = 'https://api.contratti.immobiliz.com/api/auth/contrat/create';

 id_user:any;
 token: any;
 tokenType:any;

 api_url: string;
 headers = new HttpHeaders().set('Content-Type', 'application/json');
 constructor(config: ConfigService, private httpClient: HttpClient) {
   this.api_url = config.API_URL;
 }

/*sendContrato(data: any) {
  data.id_user = localStorage.getItem('userId');
  this.tokenType  = 'Bearer ';

  const header = new HttpHeaders().set('Authorization', this.tokenType + localStorage.getItem('token'));
            const headers = { headers: header };
            return this.http.post(this.host,data,headers);
  /*let headers=new HttpHeaders();
  headers.append('authorization'
  , this.token);
  return this.http.post(this.host , data, {headers:new
    HttpHeaders({'authorization': this.token})});
}*/

async create(data:any): Promise<any> {
  data.id_user = localStorage.getItem("idUser");

  console.log("data before sending "+ JSON.stringify(data));
  const url = `${this.api_url}/auth/contrat/create`;
  const res = await this.httpClient.post(url, data).toPromise();
  return res;
}
async update(data:any): Promise<any> {
  data.id_user = localStorage.getItem("idUser");

  console.log("data before sending "+ JSON.stringify(data));
  const url = `${this.api_url}/auth/contrat/update`;
  const res = await this.httpClient.post(url, data).toPromise();
  return res;
}

cambiopassword(data:any):  Promise<any> {
  return this.httpClient.post<any>(`${this.api_url}/auth/resetpassword`, data).toPromise();
}

 filterInterrogazione(tipo: any,data: any): Promise<any> {
  return this.httpClient.post<any>(`${this.api_url}/auth/contrat/interrogation/${tipo}`, data).toPromise();

}

uploadfile(file: any,data: any,id:any) : Promise<any> {
  const formdata: FormData = new FormData();
  console.log(file);
  console.log(id);
  console.log(data);
  formdata.append('documenti',file);
  formdata.append('note',data.note);
  formdata.append('tipo_doc',data.tipo_doc);
  formdata.append('id_contrat',id);

  const headers = new HttpHeaders();
    /* In Angular 5, including the header Content-Type can invalidate your request */
    headers.append('Content-Type', 'multipart/form-data');
    headers.append('Accept', 'application/json');


  return this.httpClient.post<any>(`${this.api_url}/auth/contrat/upload`, formdata).toPromise();


}

async getAll(): Promise<any> {
  const url = `${this.api_url}/auth/contrat/list`;
  const res = await this.httpClient.get(url).toPromise();
  return res;
}



}
