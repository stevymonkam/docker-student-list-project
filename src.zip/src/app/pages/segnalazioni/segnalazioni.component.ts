import { Component, OnInit, ViewChild } from '@angular/core';
import { faCoffee } from '@fortawesome/free-solid-svg-icons';
import * as $ from 'jquery';
import {  MatSort } from '@angular/material/sort';
import {MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router} from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ContratService } from 'src/app/service/contrat/contrat.service';
import { FormValidationService } from 'src/app/service/validation/form-validation.service';





export interface conttatoElement {
  sel: string;
  tipologia: string;
  contratto: string;
  note: string;
  documenti: string;

}



const conttatoElement: conttatoElement[] = [
  {sel: '', tipologia: '', contratto: '', note: '', documenti: 'contratto.pdf'},
  {sel: '', tipologia: '', contratto: '', note: '', documenti: ''},
  {sel: '', tipologia: '', contratto: '', note: '', documenti: ''},
];


@Component({
  selector: 'app-segnalazioni',
  templateUrl: './segnalazioni.component.html',
  styleUrls: ['./segnalazioni.component.scss']
})
export class SegnalazioniComponent implements OnInit {

 //@ViewChild(MatPaginator) paginator: MatPaginator;
  //@ViewChild(MatSort) sort: MatSort;
  displayedColumns: string[] = ['azienda', 'id', 'tipologia_contratto', 'sede', 'stato_contratto', 'data_scadenza', 'preavviso', 'owner', 'fornitore'];
  displayedColumns1: string[] = ['sel', 'tipologia', 'contratto', 'note', 'documenti'];
  dataSource1:any=conttatoElement;
  faCoffee = faCoffee;
  valid:boolean = false;
  fa: FormGroup;
  fa1: FormGroup;
  submitted:boolean = false;
  loading: boolean = false;
  rows:any;
  vet = [];
  toto = [];
  rowCount: any;
  search: any=''
  @ViewChild("paginatorcontrat", {static: false}) paginatorcontrat: MatPaginator | undefined;
  @ViewChild("sortcontrat") sortcontrat: MatSort | undefined;
  dataSource: any;
  constructor( private modalService: NgbModal, private router: Router,private sendcontrato: ContratService,private validationService: FormValidationService,private fb: FormBuilder ) {
    //this.paginator = ;
    //this.dataSource = new MatTableDataSource(ELEMENT_DATA);
    //setTimeout(() => this.dataSource.paginator = this.paginator);
    //setTimeout(() => this.dataSource.sort = this.sort);
    this.fa = this.validationService.detagliocontratoForm(null,'');
     this.loadTable(false);
     this.fa1 = fb.group({
      'cars': [null, Validators.required],
      'value': [null, Validators.required]
    });
  }

  onChangeSelect() {
    //console.log(hello);
  }

  loadTable(loadOrNot:boolean) {
    this.loading=loadOrNot;
    this.sendcontrato.getAll().then((data) => {
      //console.log(data);
      this.rows = data.data;
      this.toto = data.data;
      this.rowCount = data.data.length;
      this.dataSource = new MatTableDataSource(this.rows);

      setTimeout(() => (this.dataSource.paginator = this.paginatorcontrat));
      setTimeout(() => (this.dataSource.sort = this.sortcontrat));
      this.loading=false;
    }).catch((error) => {
      console.log(error);
    });
  }

  public doFilter = () => {
    this.dataSource.filter = this.search.trim().toLocaleLowerCase();
  };

  onChange(value:string){
    console.log(value);
    this.dataSource.filterPredicate = (data: any, filter: string) => {
      switch(value) {
        case "societa": {
          console.log(data.societa == filter);

          return data.societa == filter;
        }
        case "tipologia_contratto": {
          return data.tipologia_contratto == filter;
        }
        case "sede": {
          return data.sede == filter;
        }
        case "stato_contratto": {
          return data.stato_contratto == filter;
        }
        case "data_scadenza": {
          return data.data_scadenza == filter;
        }
        case "preavviso": {
          return data.preavviso == filter;
        }
        case "owner": {
          return data.owner == filter;
        }
        case "fornitore": {
          return data.fornitore == filter;
        }
        default: {
          console.log("Invalid choice");
          return null;
        }
      }
    };
  }
  openEditModal2(targetModal: any, id: any) {}

  home() {
    this.router.navigate(['home']);

  }

  inter() {
    this.router.navigate(['interrogazioni']);
  }

  nouva() {
    this.router.navigate(['footer']);

  }
  async openModalAdd(targetModal:any) {
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: "static",
      size: 'xl',
    });
  }

  ngOnInit(): void {
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  }

}
