import { Component, OnInit, ViewChild } from '@angular/core';
import { faCoffee } from '@fortawesome/free-solid-svg-icons';
import * as $ from 'jquery';
import {  MatSort } from '@angular/material/sort';
import {MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { FormValidationService } from 'src/app/service/validation/form-validation.service';
import { AuthService } from 'src/app/service/auth/auth.service';
import { ContratService } from 'src/app/service/contrat/contrat.service';
import { ThrowStmt } from '@angular/compiler';
import { Detagliocontrato } from 'src/app/models/detagliocontrato';

import { data } from 'jquery';




export interface conttatoElement {
  sel: string;
  tipologia: string;
  contratto: string;
  note: string;
  documenti: string;
}



const conttatoElement: conttatoElement[] = [
  {sel: '', tipologia: '', contratto: '', note: '', documenti: 'contratto.pdf'},
  {sel: '', tipologia: '', contratto: '', note: '', documenti: ''},
  {sel: '', tipologia: '', contratto: '', note: '', documenti: ''},
];

@Component({
  selector: 'app-interrogazioni',
  templateUrl: './interrogazioni.component.html',
  styleUrls: ['./interrogazioni.component.scss']
})
export class InterrogazioniComponent implements OnInit {

  //@ViewChild(MatPaginator) paginator: MatPaginator;
  //@ViewChild(MatSort) sort: MatSort;
  displayedColumns: string[] = ['azienda', 'id', 'tipologia_contratto', 'sede', 'stato_contratto', 'data_scadenza', 'preavviso', 'owner', 'fornitore','tipo_importo','iva','lop_cliente','data_validata','rinnovo_automatico','data_disdetta','note','data_rinnovo','periodo'];
  displayedColumns1: string[] = ['sel', 'tipologia', 'contratto', 'note', 'documenti'];
  displayedColumns2: string[] = ['data_scadenza', 'data_rinnovo', 'data_validata'];

 // displayedColumns2: string[] = ['stipula', 'rinnovo', 'scadenza', 'disdetta'];
  dataSource:any;
  dataSource1:any=conttatoElement;
  faCoffee = faCoffee;
  valid:boolean = false;
  fa1:any;
  fa2:any;
  fa:any;
  loading: boolean = false;
  rows:any;
  vet = [];
  toto = [];
  trovato1: boolean = false;
  rowCount: any;
  submitted: boolean = false;
  flag_edit: boolean = false;
  flag_normal: boolean = false;
  data_milieu:any;
  date_milieu:any;
  search: any='';
  datapas = {de: '', a: ''};

 @ViewChild("paginatorcontrat", {static: false}) paginatorcontrat: MatPaginator | undefined;
  @ViewChild("sortcontrat") sortcontrat: MatSort | undefined;
  constructor( private modalService: NgbModal,private router:Router,private fb: FormBuilder,private sendcontrato: ContratService, private validationService: FormValidationService ) {
    //this.paginator = ;
    //this.dataSource = new MatTableDataSource(ELEMENT_DATA);
    //setTimeout(() => this.dataSource.paginator = this.paginator);
    //setTimeout(() => this.dataSource.sort = this.sort);
    this.fa = this.validationService.detagliocontratoForm(null,'');
    this.loadTable(false);
    this.fa1 = fb.group({
      'tipo': [null, Validators.required],
      'data1': [null, Validators.required],
      'data2': [null, Validators.required],
    });

    this.fa2 = fb.group({
      'cars': [null, Validators.required],
      'value': [null, Validators.required]
    });
  }

  onChangeSelect() {
    //console.log(hello);
  }
  opensegnali() {

     this.router.navigate(['segnalazioni']);
   }



   home() {
    this.router.navigate(['home']);
   }



  async openModalAdd(targetModal:any) {

    this.fa = this.validationService.detagliocontratoForm(null, '');
     this.modalService.open(targetModal, {
      centered: true,
      backdrop: "static",
      size: 'xl',
    });
  }

  loadTable(loadOrNot:boolean) {
    this.loading=loadOrNot;
    this.sendcontrato.getAll().then((data) => {
      //console.log(data);
      this.rows = data.data;
      this.toto = data.data;
      this.rowCount = data.data.length;
      this.dataSource = new MatTableDataSource(this.rows);

      setTimeout(() => (this.dataSource.paginator = this.paginatorcontrat));
      setTimeout(() => (this.dataSource.sort = this.sortcontrat));
      this.loading=false;
    }).catch((error) => {
      console.log(error);
    });
  }

 async filterInterrogazione() {
   console.log(this.fa1.value.tipo);
   console.log( this.datapas.de);
   console.log( this.datapas.a);
    this.datapas.de = this.fa1.value.data1;
    this.datapas.a = this.fa1.value.data2;



   await this.sendcontrato.filterInterrogazione(this.fa1.value.tipo, this.datapas).then((data) => {

      console.log('daaaaaaaaaaa');
     //console.log(data.data);
     this.dataSource = new MatTableDataSource(data.data);
      for(let i =0; i<data.data.length; i++) {
        console.log(data.data[i].data_scadenza);
      }

      if(this.fa1.value.cars == 'sede'){
        for(let i =0; i< this.rows.length; i++) {

           if(this.rows[i].sede == this.fa1.value.value) {

               this.vet.push(this.toto[i]);

           }
         }
         this.dataSource = new MatTableDataSource(this.vet);
         this.vet = [];
       }

    }).catch((error) =>{
      console.log(error);
    })
  }

  edit() {


    console.log(this.fa1.value);

    var date1 = new Date(this.fa1.value.data1).getTime();
    var date3 = new Date(this.fa1.value.data2).getTime();
    console.log(date1);
    console.log(date3);


    /*var date1 = new Date(this.fa1.value.data1); // esemple pour tester avec le 1 er format 12/12/2021
    var date3 = new Date(this.fa1.value.data2).getTime();
    console.log(date1);
    console.log(date3);
        let ro1 = this.rows[0].data_scadenza.split('/'); // si j enleve la split() ici le resultat ne sera pas le meme
        let ro2 = ro1[2]+'-'+ ro1[1]+'-'+ro1[0];
        var dat = new Date(ro2);
        console.log(dat);
        var dat1 = new Date(ro2).getTime();
        console.log(dat1);*/
   /*var date1 = new Date(this.fa1.value.data1); // esemple pour tester avec le 2 eme format 2021-12-03
    var date3 = new Date(this.fa1.value.data2).getTime();
    console.log(date1);
    console.log(date3);
        let ro1 = this.rows[0].data_scadenza.split('-'); // si j enleve la split() ici le resultat ne sera pas le meme car il me faut convertir sa pour que sa me doone le resultat coe dans l imput que j entre
        let ro2 = ro1[0]+'-'+ ro1[1]+'-'+ro1[2];
        var dat = new Date(ro2);
        console.log(dat);
        var dat1 = new Date(ro2).getTime();
        console.log(dat1);*/

  if(date1 > date3) {
      alert('il ya pb date1 > date3');
    }
    var date11 = new Date(this.fa1.value.data1).getDate;
    console.log('date meme' + date11);

      var date2 = this.rows[0].data_scadenza.split('/');
      console.log(date2);
      let date_milie = new Date(this.rows[15].data_scadenza).getTime();
      console.log(this.rows[15].data_scadenza);

      console.log('eccoco position 15' + date_milie);
   //console.log(date1)
   // console.log(this.fa1.value.data1)
   //console.log(date1[2]+'/'+date1[1]+'/'+date1[0]);
  if(this.fa1.value.tipo == 'data_scadenza'){
     for(let i =0; i< this.rows.length; i++) {

      var date2 = this.rows[i].data_scadenza.split('/');
      console.log( date2.length);
      if(date2.length ==1){   // si le format de la date e' comsa 2021-12-03 la split ne va pas marcher par consequent la longuer sera=1 dont je retiens le format normal illustre (12-12-2021)
      let ro = this.rows[i].data_scadenza.split('-');// je m explique quand j entre en imput les 2 dates le format e' normal et la date s'affiche avec l'heure et tous le reste dont les dates qui viennent de la base de donne doivent avoir le meme format pour pouvoir donner les meme resultat et pour que la comparaison soit bone c est pourkoi toutes les dates qui viennent de la bd kelke soit leur format je fais la spilt et je met le meme format que jai in imput pour avoir le meme resultat
      this.data_milieu = ro[0]+'-'+ ro[1]+'-'+ro[2];
      this.date_milieu = new Date(this.data_milieu).getTime();
      console.log('eccooooo c est icci c est bon');

      }else{
       if(date2.length == 3){ // si la split marche je suis ici je change le format come c est dans le if

          this.data_milieu = date2[2]+'-'+ date2[1]+'-'+date2[0];
          this.date_milieu = new Date(this.data_milieu).getTime();

       }
      }


      if(date1 <= this.date_milieu && this.date_milieu <= date3) {

        console.log('c est bon');
        this.vet.push(this.toto[i]);
        this.trovato1 = true;
      }

    }
    this.dataSource = new MatTableDataSource(this.vet);
    this.vet = [];

    if(this.trovato1 == false) {
      alert('non ci sono');
      this.loadTable(false);
    }
    this.trovato1 = false;
  }

  if(this.fa1.value.tipo == 'data_rinnovo'){
    for(let i =0; i< this.rows.length; i++) {

     var date2 = this.rows[i].data_rinnovo.split('/');
     console.log( date2.length);
     if(date2.length ==1){
      let ro = this.rows[i].data_rinnovo.split('-');// je m explique quand j entre en imput les 2 dates le format e' normal et la date s'affiche avec l'heure et tous le reste dont les dates qui viennent de la base de donne doivent avoir le meme format pour pouvoir donner les meme resultat et pour que la comparaison soit bone c est pourkoi toutes les dates qui viennent de la bd kelke soit leur format je fais la spilt et je met le meme format que jai in imput pour avoir le meme resultat
      this.data_milieu = ro[0]+'-'+ ro[1]+'-'+ro[2];
      this.date_milieu = new Date(this.data_milieu).getTime();
     }else{
      if(date2.length == 3){

         this.data_milieu = date2[2]+'-'+ date2[1]+'-'+date2[0];
         this.date_milieu = new Date(this.data_milieu).getTime();

      }
     }


     if(date1 <= this.date_milieu && this.date_milieu <= date3) {

       console.log('c est bon');
       this.vet.push(this.toto[i]);
       this.trovato1 = true;
     }

   }
   this.dataSource = new MatTableDataSource(this.vet);
   this.vet = [];

   if(this.trovato1 == false) {
     alert('non ci sono');
     this.loadTable(false);
   }
   this.trovato1 = false;
 }

 if(this.fa1.value.tipo == 'data_validata'){
  for(let i =0; i< this.rows.length; i++) {

    var date2 = this.rows[i].data_validata.split('/');
    console.log( date2.length);
    if(date2.length ==1){
      let ro = this.rows[i].data_validata.split('-');// je m explique quand j entre en imput les 2 dates le format e' normal et la date s'affiche avec l'heure et tous le reste dont les dates qui viennent de la base de donne doivent avoir le meme format pour pouvoir donner les meme resultat et pour que la comparaison soit bone c est pourkoi toutes les dates qui viennent de la bd kelke soit leur format je fais la spilt et je met le meme format que jai in imput pour avoir le meme resultat
      this.data_milieu = ro[0]+'-'+ ro[1]+'-'+ro[2];
      this.date_milieu = new Date(this.data_milieu).getTime();
    }else{
     if(date2.length == 3){

        this.data_milieu = date2[2]+'-'+ date2[1]+'-'+date2[0];
        this.date_milieu = new Date(this.data_milieu).getTime();

     }
    }


    if(date1 <= this.date_milieu && this.date_milieu <= date3) {

     console.log('c est bon');
     this.vet.push(this.toto[i]);
     this.trovato1 = true;
   }

 }
 this.dataSource = new MatTableDataSource(this.vet);
 this.vet = []; // si tu n'ajourne pas vet tu aura le resultat plus le resulta precedant

 if(this.trovato1 == false) {
   alert('non ci sono');
   this.loadTable(false);
 }

 this.trovato1 = false;
}





  }
  public doFilter = () => {
    console.log('yespp' + this.search);
    this.dataSource.filter = this.search.trim().toLocaleLowerCase();


  };

  onChange1(value:string){
    console.log(value);
    this.dataSource.filterPredicate = (data: any, filter: string) => {
      switch(value) {
        case "azienda": {
          console.log(data.azienda == filter);

          return data.azienda == filter;
        }
        case "tipologia_contratto": {
          return data.tipologia_contratto == filter;
        }
        case "sede": {
          return data.sede == filter;
        }
        case "stato_contratto": {
          return data.stato_contratto == filter;
        }
        case "data_scadenza": {
          return data.data_scadenza == filter;
        }
        case "preavviso": {
          return data.preavviso == filter;
        }
        case "owner": {
          return data.owner == filter;
        }
        case "fornitore": {
          return data.fornitore == filter;
        }
        default: {
          console.log("Invalid choice");
          return null;
        }
      }
    };
  }
  onChange(a :any) {}

  openEditModal2(b:any, id:any) {}
  ngOnInit(): void {
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  }

}
