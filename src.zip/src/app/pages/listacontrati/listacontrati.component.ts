import { Component, OnInit, ViewChild } from '@angular/core';
import { faCoffee } from '@fortawesome/free-solid-svg-icons';
import * as $ from 'jquery';
import {  MatSort } from '@angular/material/sort';
import {MatTableDataSource } from '@angular/material/table';
import { MatPaginator, MatPaginatorIntl } from '@angular/material/paginator';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { FormValidationService } from 'src/app/service/validation/form-validation.service';
import { AuthService } from 'src/app/service/auth/auth.service';
import { ContratService } from 'src/app/service/contrat/contrat.service';
import { ThrowStmt } from '@angular/compiler';
import { Detagliocontrato } from 'src/app/models/detagliocontrato';









@Component({
  selector: 'app-listacontrati',
  templateUrl: './listacontrati.component.html',
  styleUrls: ['./listacontrati.component.scss']
})
export class ListacontratiComponent implements OnInit {

  //@ViewChild(MatPaginator) paginator: MatPaginator;
  //@ViewChild(MatSort) sort: MatSort;
  displayedColumns: string[] = ['azienda', 'id', 'tipologia_contratto', 'sede', 'stato_contratto', 'data_scadenza', 'preavviso', 'owner', 'fornitore'];
  displayedColumns1: string[] = ['id', 'tipo_doc', 'id_contrat', 'note', 'documenti'];
  dataSource1:any;
  faCoffee = faCoffee;
  valid:boolean = false;
  fa: FormGroup;
  fa1: FormGroup;
  fa2: FormGroup;
  submitted:boolean = false;
  loading: boolean = false;
  rows:any;
  rows1:any;
  vet = [];
  toto = [];
  rowCount: any;
  search: any='';
  fileName: any;
  rows_file:any;
  contrafile: any = 'https://bulma.io/images/placeholders/480x480.png';
  file: any;
  flag_edit: boolean = false;
  flag_normal: boolean = false;
  @ViewChild("paginatorcontrat", {static: false}) paginatorcontrat: MatPaginator | undefined;
   @ViewChild("sortcontrat") sortcontrat: MatSort | undefined;
  @ViewChild(MatSort) sort: MatSort | undefined;
  @ViewChild("paginatorcontratmodal", {static: false}) paginatorcontratmodal: MatPaginator | undefined;
  @ViewChild("sortcontratmodal") sortcontratmodal: MatSort | undefined;



  dataSource: any;
  constructor( private modalService: NgbModal,private router:Router,
    private validationService: FormValidationService,private auth: AuthService,private sendcontrato: ContratService, private fb: FormBuilder
    ) {

     this.fa = this.validationService.detagliocontratoForm(null,'');
     this.loadTable(false);
     this.fa1 = fb.group({
      'cars': [null, Validators.required],
      'value': [null, Validators.required]
    });

    this.fa2 = fb.group({
      'tipo_doc': [null, Validators.required],
      'id_contrat': [''],
      'documenti': [null],
      'note': [null, Validators.required],


    });


  }

 // edit(data: any) {}
 /* async edit(data: any) {
    await this.auth.login(data).subscribe((res: any)=>{
      console.log("one school=="+JSON.stringify(res));

    }, err =>{
      console.log("get the error ==="+JSON.stringify(err));
    });

  }*/

  public findInvalidControls(fa:FormGroup) {
    const invalid = [];
    const controls = fa.controls;
    for (const name in controls) {
      if (controls[name].invalid) {
        invalid.push(name);
      }
    }
    return invalid;
  }
  /*edit(data: any) {
   if(this.fa.valid){

    console.log("ecoooo fa contrat");
      console.log(this.fa.value);
      this.sendcontrato.sendContrato(this.fa.value).subscribe( (res) =>{
        console.log("ecoooo fa contrat dedans");

        console.log(res);
      }, err =>{
        console.log('errooo');
      })

     alert('valide');
   }else{
    this.submitted = true;

     alert('not valide');
     console.log("this.fa");
     console.log(this.fa.value);
     console.log("incompleted are =="+this.findInvalidControls(this.fa));

   }
 }*/

 /*listeContra() {

  this.sendcontrato.GetList().then(
    (res)=> {
      console.log(res);

      this.dataSource = ELEMENT_DATA;
      console.log('this.dataSource');

      console.log(this.dataSource);
    }
  ).catch(
    (error)=>{
      console.log("error"+JSON.stringify(error));
    }
  )
 }*/
 /*
 doFilter() {
 // console.log(this.fa1.value);

if(this.fa1.value.cars == 'sede'){
 for(let i =0; i< this.rows.length; i++) {

    if(this.rows[i].sede == this.fa1.value.value) {

        this.vet.push(this.toto[i]);

    }
  }
  this.dataSource = new MatTableDataSource(this.vet);
  this.vet = [];
}

if(this.fa1.value.cars == 'tipologia_contratto'){
  for(let i =0; i< this.rows.length; i++) {

     if(this.rows[i].tipologia_contratto == this.fa1.value.value) {

         this.vet.push(this.toto[i]);

     }
   }
   this.dataSource = new MatTableDataSource(this.vet);
   this.vet = [];
 }

 if(this.fa1.value.cars == 'azienda'){
  for(let i =0; i< this.rows.length; i++) {

     if(this.rows[i].azienda == this.fa1.value.value) {

         this.vet.push(this.toto[i]);

     }
   }
   this.dataSource = new MatTableDataSource(this.vet);
   this.vet = [];
 }
 if(this.fa1.value.cars == 'owner'){
  for(let i =0; i< this.rows.length; i++) {

     if(this.rows[i].owner == this.fa1.value.value) {

         this.vet.push(this.toto[i]);

     }
   }
   this.dataSource = new MatTableDataSource(this.vet);
   this.vet = [];
 }
 if(this.fa1.value.cars == 'fornitore'){
  for(let i =0; i< this.rows.length; i++) {

     if(this.rows[i].fornitore == this.fa1.value.value) {

         this.vet.push(this.toto[i]);

     }
   }
   this.dataSource = new MatTableDataSource(this.vet);
   this.vet = [];
 }
 if(this.fa1.value.cars == "" || this.fa1.value.cars == null || this.fa1.value.value == null || this.fa1.value.value == "") {

  this.loadTable(false);
 }






};
*/
/*onChangeSelect2(value: string) {
  //console.log(value);

 localStorage.setItem('value1',value);

}*/

public doFilter = () => {
  this.dataSource.filter = this.search.trim().toLocaleLowerCase();
};

onChange(value:string){
  console.log(value);
  this.dataSource.filterPredicate = (data: any, filter: string) => {
    switch(value) {
      case "azienda": {
        console.log(data.azienda == filter);

        return data.azienda == filter;
      }
      case "tipologia_contratto": {
        return data.tipologia_contratto == filter;
      }
      case "sede": {
        return data.sede == filter;
      }
      case "stato_contratto": {
        return data.stato_contratto == filter;
      }
      case "data_scadenza": {
        return data.data_scadenza == filter;
      }
      case "preavviso": {
        return data.preavviso == filter;
      }
      case "owner": {
        return data.owner == filter;
      }
      case "fornitore": {
        return data.fornitore == filter;
      }
      default: {
        console.log("Invalid choice");
        return null;
      }
    }
  };
}
 loadTable(loadOrNot:boolean) {
  this.loading=loadOrNot;
  this.sendcontrato.getAll().then((data) => {
    //console.log(data);
    this.rows = data.data;
    this.toto = data.data;
    this.rowCount = data.data.length;
    this.dataSource = new MatTableDataSource(this.rows);
    console.log(this.rows);



    setTimeout(() => (this.dataSource.paginator = this.paginatorcontrat));
    setTimeout(() => (this.dataSource.sort = this.sort));
    this.loading=false;
  }).catch((error) => {
    console.log(error);
  });
}
loadTable2(data:any) {
  const rows_file = data;


}


onChangefile(file: File) {

  console.log(file);
   this.file = file;

}

  async onfile() {

  await this.sendcontrato.uploadfile(this.file,this.fa2.value,this.fa.value.id_contrat).then((data) =>{

    console.log(JSON.stringify(data));
    console.log('upload');
    console.log(data.data);
    this.loadTable2(data.data);

   // this.loadTable2(data.data);


    }).catch((error) =>{
      console.log(error);
    })

  }


 edit1() {


 // console.log("form data"+JSON.stringify(this.fa.value));
  //console.log(this.fa.value);

  if(this.fa.valid){
    this.sendcontrato.create(this.fa.value).then(
      (data)=>{

        this.loadTable(false);
        console.log("response"+JSON.stringify(data));
        console.log(data);
        alert('contrat enreigistre dans la bd');
        this.modalService.dismissAll();

      }
    ).catch(
      (error)=>{
        console.log("error"+JSON.stringify(error));
      }
    )
    //alert('cest bon');
  } else {
    this.submitted = true;
    console.log("incompleted are =="+this.findInvalidControls(this.fa));
    /* alert ("pas bon"); */
  }
}

edit2() {
  alert('edit');
  console.log('this.fa.value');
  console.log(this.fa.value);
  if(this.fa.valid){
    alert('dedans');
  this.sendcontrato.update(this.fa.value).then(
    (data) => {
      console.log('contrat aggiorner avec succes');
      console.log(data);
      this.loadTable(false);
      alert('contrat aggiorner avec succes');
      this.modalService.dismissAll();

    }
  ).catch(
    (error)=>{
      alert('erroooooor');
      console.log("error"+JSON.stringify(error));
    }
  )
} else {
  this.submitted = true;
  console.log("incompleted are =="+this.findInvalidControls(this.fa));
  /* alert ("pas bon"); */
}
}

  onChangeSelect() {
    //console.log(hello);
  }
  opensegnali() {

     this.router.navigate(['segnalazioni']);
   }

   openinterrogazioni() {
    this.router.navigate(['interrogazioni']);


   }

  async add() {

    if(this.fa.valid){
      alert('cest bon');
    }

  }

  async openModalAdd(targetModal:any) {

    this.flag_normal = true;
    this.flag_edit = false;
     this.fa = this.validationService.detagliocontratoForm(null, '');
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: "static",
      size: 'xl',
    });
  }

  openEditModal(targetModal: any) {



  }
  openEditModal2(targetModal: any, id: any) {
  console.log('qqqqq');
    this.flag_normal = false;
    this.flag_edit = true;
   // console.log('voici id');
   // console.log( this.rows[id].sede,
     // this.rows[id].azienda);

  let detaglio;
  console.log("this.rows == " + JSON.stringify(this.rows));
  let data = this.rows.filter( (x:any) => x.id == id);
  console.log("this.data == " + JSON.stringify(data));
  console.log('eccooooooooooooooo dattttttttttttt');
  console.log(data[0].file_contrat);
  this.dataSource1 = new MatTableDataSource(data[0].file_contrat);
    setTimeout(() => (this.dataSource1.paginator = this.paginatorcontratmodal));
    setTimeout(() => (this.dataSource1.sort = this.sortcontratmodal));
  //this.loadTable2(data[0].file_contrat);
  detaglio = new Detagliocontrato(
 data[0].id,
 data[0].id_user,
 data[0].owner,
 data[0].sede,
 data[0].azienda,
 data[0].codice,
 data[0].tipo_importo,
 data[0].fornitore,
 data[0].iva,
 data[0].lop_cliente,
 data[0].tipologia_contratto,
 data[0].stato_contratto,
 data[0].data_validata,
 data[0].rinnovo_automatico,
 data[0].data_disdetta,
 data[0].note,
 data[0].mail_preavviso,
 data[0].mail_contratto,
 data[0].data_rinnovo,
 data[0].periodo,
 data[0].preavviso,
 data[0].data_scadenza,
);
console.log(this.rows);


console.log('voici id');
console.log(id);
console.log(detaglio);



    this.fa = this.validationService.detagliocontratoForm(detaglio,'edit');
    console.log(this.fa);
    this.modalService.open(targetModal, {
      centered: true,
      backdrop: "static",
      size: 'xl',
    });
  }

  opensignalisazioni() {

    this.router.navigate(['segnalazioni']);
  }
  ngOnInit(): void {
   console.log(this.rows);
   this.loadTable(false);
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  }

}
